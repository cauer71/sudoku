repo: cauer71/sudoku
branch: claude/sudoku-game-public-oi4w96

## Last sync
date: 2026-08-16T17:52:05Z

### Updated in this project
- Komplettes Redesign in Material 3 Expressive (Seed #1E4FA6, hell/dunkel nach Systemeinstellung)
- Material Symbols Rounded als Icon-Satz, material-web (md-filled-button, md-text-button, md-switch) im Menü
- Menü als Bottom Sheet, Segmented Button für die vier Schwierigkeitsgrade, Shape-Morph beim Drücken
- Spiel-Logik 1:1 aus index.html übernommen (Erzeugung mit Eindeutigkeitsprüfung, Grade, Notizen, Undo/Redo, Tipps, Bestzeiten, Speicherstand)

## Screen map
| Screen | Repo-Dateien |
|---|---|
| M3 Sudoku.dc.html (Spiel, alle Zustände) | index.html (Style-Block, Markup, Script-Block) |
| Sudoku M3 Optionen.dc.html (drei Richtungen) | index.html |
